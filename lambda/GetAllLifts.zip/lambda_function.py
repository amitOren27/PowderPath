import json
import psycopg2

def lambda_handler(event, context):

    try:
        conn = psycopg2.connect(
            host="osm-data.cplugomkwhlt.us-east-1.rds.amazonaws.com",
            dbname="osm-data",
            user="postgres",
            password="powderpath",
            port="5432"
        )
        cur = conn.cursor()

        # Query to return GeoJSON for each feature
        cur.execute("""
            SELECT 
                jsonb_build_object(
                    'type', 'Feature',
                    'geometry', ST_AsGeoJSON(ST_Transform(geom, 4326))::jsonb, 
                    'properties', to_jsonb(aerialway_lines) - 'geom'
                )
            FROM aerialway_lines
            
        """)

        features = [row[0] for row in cur.fetchall()]
        geojson = {
            "type": "FeatureCollection",
            "features": features
        }

        cur.close()
        conn.close()

        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps(geojson)
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }