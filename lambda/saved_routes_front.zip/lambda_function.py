import json, psycopg2

def _json(status, data):
    return {
        "statusCode": status,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Content-Type": "application/json"
        },
        "body": json.dumps(data, ensure_ascii=False)
    }

def _open_conn():
    return psycopg2.connect(
        host="osm-data.cplugomkwhlt.us-east-1.rds.amazonaws.com",
        dbname="osm-data",
        user="postgres",
        password="powderpath",
        port="5432"
    )

def _has_col(cur, name):
    cur.execute("""
      SELECT 1 FROM information_schema.columns
      WHERE table_schema='public' AND table_name='saved_routes' AND column_name=%s
      LIMIT 1;
    """, (name,))
    return cur.fetchone() is not None

def _parse_json_val(v):
    if v is None:
        return []
    if isinstance(v, (list, dict)):
        return v
    if isinstance(v, (bytes, bytearray, memoryview)):
        try: v = bytes(v).decode("utf-8")
        except Exception: return []
    if isinstance(v, str):
        try: return json.loads(v)
        except Exception: return []
    return []

def _select_cols(include_stops):
    base = """
      id,
      user_id,
      COALESCE(route_name, '') AS route_name,
      COALESCE(start_name, '') AS start_name,
      ST_Y(start_point) AS start_lat,
      ST_X(start_point) AS start_lng,
      COALESCE(end_name, '') AS end_name,
      ST_Y(end_point) AS end_lat,
      ST_X(end_point) AS end_lng
    """
    if include_stops:
        # CAST ל-jsonb גם אם העמודה נוצרה כ-TEXT
        return base + ", COALESCE((stops_json)::jsonb, '[]'::jsonb) AS stops_json"
    return base

def _row_to_item(row, include_stops):
    if include_stops:
        stops = _parse_json_val(row[9])
        return {
            "id": row[0],
            "user_id": row[1],
            "route_name": row[2],
            "start": {"name": row[3], "lat": row[4], "lng": row[5]},
            "end":   {"name": row[6], "lat": row[7], "lng": row[8]},
            "stops": stops
        }
    return {
        "id": row[0],
        "user_id": row[1],
        "route_name": row[2],
        "start": {"name": row[3], "lat": row[4], "lng": row[5]},
        "end":   {"name": row[6], "lat": row[7], "lng": row[8]},
    }

def lambda_handler(event, context):
    method = (event.get("requestContext", {}).get("http", {}).get("method")
              or event.get("httpMethod", "GET")).upper()
    if method != "GET":
        return _json(405, {"error": "Method Not Allowed"})

    params = event.get("queryStringParameters") or {}
    user_id = params.get("user_id")
    if not user_id:
        return _json(400, {"error": "user_id is required"})

    route_id = params.get("id")
    try:
        limit = int(params.get("limit", "20"))
    except ValueError:
        limit = 20
    limit = max(1, min(limit, 50))

    conn = cur = None
    try:
        conn = _open_conn()
        cur = conn.cursor()

        has_stops = _has_col(cur, "stops_json")
        cols = _select_cols(has_stops)

        if route_id:
            cur.execute(f"""
              SELECT {cols}
              FROM saved_routes
              WHERE user_id = %s AND id = %s;
            """, (user_id, route_id))
            row = cur.fetchone()
            if not row:
                return _json(200, {"items": []})
            return _json(200, {"items": [_row_to_item(row, has_stops)]})

        cur.execute(f"""
          SELECT {cols}
          FROM saved_routes
          WHERE user_id = %s
          ORDER BY id DESC
          LIMIT %s;
        """, (user_id, limit))
        rows = cur.fetchall()
        items = [_row_to_item(r, has_stops) for r in rows]
        return _json(200, {"items": items})

    except Exception:
        return _json(500, {"error": "Internal Error"})
    finally:
        try:
            if cur: cur.close()
        finally:
            if conn: conn.close()
