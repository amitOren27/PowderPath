# lambda: SAVED_ROUTES_URL
import json, hashlib, psycopg2
from psycopg2.extras import Json

DEBUG = True

def _json(status, data):
    return {
        "statusCode": status,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, Authorization",
            "Access-Control-Max-Age": "3600",
            "Content-Type": "application/json",
        },
        "body": json.dumps(data, ensure_ascii=False)
    }

def _get_user_id(event, body):
    try:
        return event["requestContext"]["authorizer"]["jwt"]["claims"]["sub"]
    except Exception:
        pass
    try:
        return event["requestContext"]["authorizer"]["claims"]["sub"]
    except Exception:
        pass
    return body.get("user_id")

def _open_conn():
    return psycopg2.connect(
        host="osm-data.cplugomkwhlt.us-east-1.rds.amazonaws.com",
        dbname="osm-data",
        user="postgres",
        password="powderpath",
        port="5432"
    )

def r6(x): return round(float(x), 6)

def _norm_stop(s, fallback_name):
    name = (s.get("name") or fallback_name or "").strip()
    lat  = r6(s["lat"])
    lng  = r6(s["lng"])
    return {"name": name, "lat": lat, "lng": lng}

def _hash_stops(stops):
    canon = json.dumps(
        [{"lat": st["lat"], "lng": st["lng"]} for st in stops],
        ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    return hashlib.sha256(canon.encode("utf-8")).hexdigest()

def _table_has_columns(cur, cols):
    cur.execute("""
      SELECT column_name FROM information_schema.columns
      WHERE table_schema='public' AND table_name='saved_routes';
    """)
    have = {r[0] for r in cur.fetchall()}
    return all(c in have for c in cols)

def lambda_handler(event, context):
    method = (event.get("requestContext", {}).get("http", {}).get("method")
              or event.get("httpMethod", "POST")).upper()

    if method == "OPTIONS":
        return _json(200, {})
    if method != "POST":
        return _json(405, {"error": "Method Not Allowed"})

    try:
        body = json.loads(event.get("body") or "{}")
    except json.JSONDecodeError:
        return _json(400, {"error": "Invalid JSON body"})

    user_id = _get_user_id(event, body)
    if not user_id:
        return _json(401, {"error": "Unauthorized"})

    try:
        raw_stops = body.get("stops")
        if isinstance(raw_stops, list) and len(raw_stops) >= 2:
            stops = [_norm_stop(s, "Start" if i == 0 else "End" if i == len(raw_stops)-1 else "Stop")
                     for i, s in enumerate(raw_stops)]
        else:
            start = body.get("start"); end = body.get("end")
            if not (isinstance(start, dict) and isinstance(end, dict)):
                return _json(400, {"error": "stops or start/end are required"})
            stops = [_norm_stop(start, "Start"), _norm_stop(end, "End")]
    except Exception as e:
        if DEBUG: print("norm stops error:", repr(e), flush=True)
        return _json(400, {"error": "invalid stops array"})

    start, end = stops[0], stops[-1]
    route_name = (body.get("route_name")
                  or (f'{start["name"]} → {end["name"]}' if start["name"] and end["name"]
                      else f'({start["lat"]:.5f},{start["lng"]:.5f}) → ({end["lat"]:.5f},{end["lng"]:.5f})'))

    # נבנה גם WKT של מסלול (לתאימות לאילוץ route_data NOT NULL אם קיים)
    route_wkt = "LINESTRING(" + ", ".join(f"{st['lng']} {st['lat']}" for st in stops) + ")"

    if DEBUG:
        print("DEBUG user_id:", user_id, flush=True)
        print("DEBUG route_name:", route_name, flush=True)
        print("DEBUG stops:", stops, flush=True)
        print("DEBUG wkt:", route_wkt, flush=True)

    conn = cur = None
    try:
        conn = _open_conn()
        cur = conn.cursor()

        has_new = _table_has_columns(cur, ["stops_json", "stops_hash"])
        if DEBUG: print("DEBUG has_new_cols:", has_new, flush=True)

        if has_new:
            stops_hash = _hash_stops(stops)
            if DEBUG: print("DEBUG stops_hash:", stops_hash, flush=True)

            # בדיקת כפילות: אותו רצף נקודות
            cur.execute("""
              SELECT id, route_name
              FROM saved_routes
              WHERE user_id = %s AND stops_hash = %s;
            """, (user_id, stops_hash))
            row = cur.fetchone()
            if DEBUG: print("DEBUG dup check:", row, flush=True)
            if row:
                conn.commit()
                return _json(200, {"ok": True, "exists": True, "id": row[0], "route_name": row[1]})

            # INSERT מלא – כולל route_data לתאימות
            cur.execute("""
              INSERT INTO saved_routes
                (user_id, route_name,
                 start_name, start_point, start_x6, start_y6,
                 end_name,   end_point,   end_x6,   end_y6,
                 stops_json, stops_hash, route_data)
              VALUES
                (%s, %s,
                 %s, ST_SetSRID(ST_MakePoint(%s,%s),4326), %s, %s,
                 %s, ST_SetSRID(ST_MakePoint(%s,%s),4326), %s, %s,
                 %s, %s, ST_SetSRID(ST_GeomFromText(%s),4326))
              RETURNING id;
            """, (
                user_id, route_name,
                start["name"], start["lng"], start["lat"], r6(start["lng"]), r6(start["lat"]),
                end["name"],   end["lng"],   end["lat"],   r6(end["lng"]),   r6(end["lat"]),
                Json(stops), stops_hash, route_wkt
            ))
            new_id = cur.fetchone()[0]
            conn.commit()
            if DEBUG: print("DEBUG inserted id:", new_id, flush=True)
            return _json(200, {"ok": True, "exists": False, "id": new_id, "route_name": route_name})

        # ─── מסלול ישן (ללא העמודות החדשות) ───
        cur.execute("""
          SELECT id, route_name
          FROM saved_routes
          WHERE user_id = %s
            AND start_x6 = %s AND start_y6 = %s
            AND end_x6   = %s AND end_y6   = %s;
        """, (user_id, r6(start["lng"]), r6(start["lat"]), r6(end["lng"]), r6(end["lat"])))
        row = cur.fetchone()
        if DEBUG: print("DEBUG legacy dup check:", row, flush=True)
        if row:
            conn.commit()
            return _json(200, {"ok": True, "exists": True, "id": row[0], "route_name": row[1]})

        cur.execute("""
          INSERT INTO saved_routes
            (user_id, route_name,
             start_name, start_point, start_x6, start_y6,
             end_name,   end_point,   end_x6,   end_y6,
             route_data)
          VALUES
            (%s, %s,
             %s, ST_SetSRID(ST_MakePoint(%s,%s),4326), %s, %s,
             %s, ST_SetSRID(ST_MakePoint(%s,%s),4326), %s, %s,
             ST_SetSRID(ST_GeomFromText(%s),4326))
          RETURNING id;
        """, (
            user_id, route_name,
            start["name"], start["lng"], start["lat"], r6(start["lng"]), r6(start["lat"]),
            end["name"],   end["lng"],   end["lat"],   r6(end["lng"]),   r6(end["lat"]),
            route_wkt
        ))
        new_id = cur.fetchone()[0]
        conn.commit()
        if DEBUG: print("DEBUG legacy inserted id:", new_id, flush=True)
        return _json(200, {"ok": True, "exists": False, "id": new_id, "route_name": route_name})

    except psycopg2.Error as e:
        try:
            if conn: conn.rollback()
        except Exception:
            pass
        # חשיפה זמנית של פירוט PostgreSQL ללוגים ולתגובה (לדיבוג)
        print("PG ERROR:", e.pgcode, e.pgerror, flush=True)
        return _json(500, {"error": "DB error", "pgcode": e.pgcode, "pgerror": e.pgerror})
    except Exception as e:
        try:
            if conn: conn.rollback()
        except Exception:
            pass
        if DEBUG: print("GENERIC ERROR:", repr(e), flush=True)
        return _json(500, {"error": "Internal error"})
    finally:
        try:
            if cur: cur.close()
        finally:
            if conn: conn.close()
