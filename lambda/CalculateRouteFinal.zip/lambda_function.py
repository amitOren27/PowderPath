
import json
import math
import psycopg2
import shapely.wkb
from shapely.ops import linemerge
from shapely.geometry import mapping as shp_mapping


ALLOWED_DIFFICULTIES = {"novice","easy","intermediate","advanced","expert","freeride"}


def build_difficulty_clause(cur, allowed_list):
    """
    Returns a WHERE snippet like:
    AND (e.difficulty IS NULL OR e.difficulty = ANY(ARRAY['easy','intermediate']::text[]))
    If allowed_list is empty or None, returns an empty string (no filter).
    """
    if not allowed_list:
        return ""
    vals = ",".join(cur.mogrify("%s", (v,)).decode("utf-8") for v in allowed_list)
    allowed_array = f"ARRAY[{vals}]::text[]"
    return f" AND (e.difficulty IS NULL OR e.difficulty = ANY({allowed_array}))"


def route_length_m(cur, start_vid, end_vid, difficulty_clause):
    """
    Returns the total route length in meters between two vertex ids using pgRouting.
    If no route exists, returns None.
    Uses an aggregate query to avoid transferring all edges.
    """
    inner_sql = f"""
        SELECT e.id, e.source, e.target, e.cost
        FROM routing_edges e
        WHERE TRUE{difficulty_clause}
    """
    cur.execute("""
        WITH dj AS (
        SELECT edge FROM pgr_dijkstra(%s, %s, %s, directed := true)
        )
        SELECT SUM(ST_Length(ST_Transform(e.geom, 3857)))::float AS len_m
        FROM dj
        JOIN routing_edges e ON e.id = dj.edge;
    """, (inner_sql, int(start_vid), int(end_vid)))
    row = cur.fetchone()
    if not row or row[0] is None:
        return None
    return float(row[0])


def route_edges(cur, start_vid, end_vid, difficulty_clause):
    """
    Returns a list of edges (osm_id, name, difficulty, geom_wkb) along the path.
    Used only for the chosen legs, to build merged segments for the frontend.
    """
    inner_sql = f"""
        SELECT e.id, e.source, e.target, e.cost
        FROM routing_edges e
        WHERE TRUE{difficulty_clause}
    """
    cur.execute("""
        SELECT e.osm_id, e.name, e.difficulty, ST_AsBinary(ST_Transform(e.geom, 4326))
        FROM pgr_dijkstra(%s, %s, %s, directed := true) AS path
        JOIN routing_edges e ON path.edge = e.id
        ORDER BY path.seq;
    """, (inner_sql, int(start_vid), int(end_vid)))

    return cur.fetchall() # [(osm_id, name, difficulty, geom_wkb), ...]


def merge_consecutive_segments(rows):
    """
    rows: [(osm_id, name, difficulty, geom_wkb), ...] ordered along the path
    Returns merged list with same columns but geometry merged (as GeoJSON dict).
    """
    grouped = []
    current_key = None
    current_geoms = []

    for osm_id, name, difficulty, geom_wkb in rows:
        key = (osm_id, name, difficulty)
        geom = shapely.wkb.loads(bytes(geom_wkb))
        if key == current_key:
            current_geoms.append(geom)
        else:
            if current_geoms:
                merged = linemerge(current_geoms)
                grouped.append({
                    "osm_id": current_key[0],
                    "name": current_key[1],
                    "difficulty": current_key[2],
                    "geometry": shp_mapping(merged)
                })
            current_key = key
            current_geoms = [geom]


    if current_geoms:
        merged = linemerge(current_geoms)
        grouped.append({
            "osm_id": current_key[0],
            "name": current_key[1],
            "difficulty": current_key[2],
            "geometry": shp_mapping(merged)
        })

    return grouped


def lambda_handler(event, context):
    try:
        payload = json.loads(event.get("body") or "{}")

        # Read inputs
        candidates = payload.get("candidates")
        if not candidates or not isinstance(candidates, list) or not all(isinstance(layer, list) for layer in candidates):
            return {"statusCode": 400, "body": json.dumps({"error": "'candidates' must be a list of lists"})}


        # for debug/sanity
        stops = payload.get("stops") or None

        # Sanitize candidate objects and enforce required fields
        layers = []
        for idx, layer in enumerate(candidates):
            clean = []
            for c in layer:
                if not isinstance(c, dict):
                    continue
                if "id" not in c or "lat" not in c or ("lon" not in c and "lng" not in c) or "walk_in_m" not in c:
                    continue
                clean.append({
                    "id": int(c["id"]),
                    "lat": float(c["lat"]),
                    "lon": float(c.get("lon", c.get("lng"))),
                    "walk_in_m": float(c["walk_in_m"]) # meters from stop to this candidate
                })
            if not clean:
                return {"statusCode": 400, "body": json.dumps({"error": f"candidates[{idx}] is empty or invalid"})}
            layers.append(clean)

        N = len(layers) # number of stops
        if N < 2:
            return {"statusCode": 400, "body": json.dumps({"error": "need at least 2 stops/candidate layers"})}

        # Weights
        w = payload.get("weights") or {}
        w_walk = float(w.get("w_walk", 3.0))
        w_route = float(w.get("w_route", 1.0))

        # Difficulty filter
        incoming_allowed = payload.get("allowed") or []
        allowed = [d for d in incoming_allowed if d in ALLOWED_DIFFICULTIES]

        # DB connect (same as current lambdas)
        conn = psycopg2.connect(
            host="osm-data.cplugomkwhlt.us-east-1.rds.amazonaws.com",
            dbname="osm-data",
            user="postgres",
            password="powderpath",
            port="5432"
        )

        with conn.cursor() as cur:
            diff_clause = build_difficulty_clause(cur, allowed)

            # Precompute pairwise network lengths for each leg i between every candidate in layers[i] and layers[i+1]
            lengths = [] # lengths[i][j][k] = meters or None
            for i in range(N - 1):
                A = layers[i]
                B = layers[i + 1]
                Mi, Mj = len(A), len(B)
                mat = [[None for _ in range(Mj)] for __ in range(Mi)]
                for j, a in enumerate(A):
                    for k, b in enumerate(B):
                        L = route_length_m(cur, a["id"], b["id"], diff_clause)
                        mat[j][k] = None if (L is None or (isinstance(L, float) and math.isinf(L))) else float(L)
                lengths.append(mat)

            # Quick feasibility check: each leg must have at least one finite route
            for i, mat in enumerate(lengths):
                if not any(any(cell is not None for cell in row) for row in mat):
                    return {"statusCode": 400, "body": json.dumps({"error": f"no network path between candidate sets for leg {i}"})}

            # Per‑leg independent optimal choices
            leg_choices = [] # (i, j_best, k_best, L_best)
            total_route_m = 0.0
            for i in range(N - 1):
                A = layers[i]
                B = layers[i + 1]
                mat = lengths[i]
                best = None
                for j, a in enumerate(A):
                    for k, b in enumerate(B):
                        L = mat[j][k]
                        if L is None:
                            continue
                        # Base walking cost: include source walk only for first leg
                        walk_cost = (w_walk * A[j]["walk_in_m"] if i == 0 else 0.0) + (w_walk * B[k]["walk_in_m"]) # dest walk always counts
                        cost = w_route * L + walk_cost
                        if best is None or cost < best[0]:
                            best = (cost, j, k, L)
                # best must exist due to feasibility check
                leg_choices.append((i, best[1], best[2], best[3]))
                total_route_m += float(best[3])

            # Build 'snapped' per stop and reconstruct/merge edges for each leg
            # snapped[i] rule: for i==0 use source of leg0; for i in (1..N-2) use source of leg i; for i==N-1 use target of last leg
            snapped = [None] * N
            for i in range(N - 1):
                j_best = leg_choices[i][1]
                snapped[i] = {"id": layers[i][j_best]["id"], "lat": layers[i][j_best]["lat"], "lon": layers[i][j_best]["lon"]}
            # destination snapped
            j_last, k_last = leg_choices[-1][1], leg_choices[-1][2]
            snapped[N - 1] = {"id": layers[N - 1][k_last]["id"], "lat": layers[N - 1][k_last]["lat"], "lon": layers[N - 1][k_last]["lon"]}

            route_segments = []
            legs_out = []
            for i in range(N - 1):
                j_best = leg_choices[i][1]
                k_best = leg_choices[i][2]
                a = layers[i][j_best]
                b = layers[i + 1][k_best]
                rows = route_edges(cur, a["id"], b["id"], diff_clause)
                merged = merge_consecutive_segments(rows)
                route_segments.extend(merged)
                legs_out.append({
                    "from_idx": int(j_best),
                    "to_idx": int(k_best),
                    "route_m": float(leg_choices[i][3])
                })

            # Walking totals consistent with per‑leg accounting
            walk_in_m_sum = float(layers[0][leg_choices[0][1]]["walk_in_m"]) # source of first leg
            for i in range(N - 1):
                k_best = leg_choices[i][2]
                walk_in_m_sum += float(layers[i + 1][k_best]["walk_in_m"]) # dest of each leg

            total_cost = w_walk * walk_in_m_sum + w_route * total_route_m

        return {
            "statusCode": 200,
            "body": json.dumps({
                "mode": "optimize",
                "weights": {"w_walk": w_walk, "w_route": w_route},
                "allowed": allowed,
                "snapped": snapped,
                "route": route_segments,
                "legs": legs_out,
                "totals": {
                    "walk_in_m_sum": walk_in_m_sum,
                    "route_m_sum": total_route_m,
                    "cost": total_cost
                }
            })
        }

    except Exception as e:
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}