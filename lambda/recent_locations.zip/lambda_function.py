import json
import psycopg2

def _json(status, data):
    return {
        "statusCode": status,
        "headers": {
            "Access-Control-Allow-Origin": "*",  # או שים כאן את הדומיין של Amplify
            "Content-Type": "application/json"
        },
        "body": json.dumps(data, ensure_ascii=False)
    }

def _get_user_id(event):
    # HTTP API (JWT authorizer)
    try:
        return event["requestContext"]["authorizer"]["jwt"]["claims"]["sub"]
    except Exception:
        pass
    # REST API (Cognito authorizer)
    try:
        return event["requestContext"]["authorizer"]["claims"]["sub"]
    except Exception:
        pass
    return None

def lambda_handler(event, context):
    method = (event.get("requestContext", {}).get("http", {}).get("method")
              or event.get("httpMethod", "POST")).upper()

    # אופציונלי: מענה ל-preflight אם יגיע
    if method == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Authorization",
                "Access-Control-Max-Age": "3600"
            },
            "body": ""
        }

    if method != "POST":
        return _json(405, {"error": "Method Not Allowed"})

    # --- קודם מפענחים את ה-body ---
    try:
        body = json.loads(event.get("body") or "{}")
    except json.JSONDecodeError:
        return _json(400, {"error": "Invalid JSON body"})

    # --- Fallback ל-user_id: JWT או מה-body (Function URL) ---
    user_id = _get_user_id(event) or body.get("user_id")
    if not user_id:
        return _json(401, {"error": "Unauthorized"})

    name = body.get("name")
    lat  = body.get("lat")
    lng  = body.get("lng")
    if not name or not isinstance(lat, (int, float)) or not isinstance(lng, (int, float)):
        return _json(400, {"error": "name, lat, lng are required"})

    conn = None
    cur = None
    try:
        conn = psycopg2.connect(
            host="osm-data.cplugomkwhlt.us-east-1.rds.amazonaws.com",
            dbname="osm-data",
            user="postgres",
            password="powderpath",
            port="5432"
        )
        cur = conn.cursor()

        # אם כבר קיימת אותה רשומה לאותו user+שם+נקודה – לא נכפיל
        cur.execute(
            """
            SELECT id, user_id, location_name,
                   ST_Y(coordinates) AS lat, ST_X(coordinates) AS lng
            FROM recent_locations
            WHERE user_id = %s
              AND location_name = %s
              AND ST_Equals(
                    coordinates,
                    ST_SetSRID(ST_MakePoint(%s, %s), 4326)
                  );
            """,
            (user_id, name, lng, lat)
        )
        row = cur.fetchone()
        if row:
            conn.commit()
            return _json(200, {
                "ok": True,
                "location": {
                    "id": row[0], "user_id": row[1], "name": row[2],
                    "lat": row[3], "lng": row[4]
                },
                "exists": True
            })

        # אחרת – נכניס חדשה
        cur.execute(
            """
            INSERT INTO recent_locations (user_id, location_name, coordinates)
            VALUES (%s, %s, ST_SetSRID(ST_MakePoint(%s, %s), 4326))
            RETURNING id, user_id, location_name,
                      ST_Y(coordinates) AS lat, ST_X(coordinates) AS lng;
            """,
            (user_id, name, lng, lat)
        )
        row = cur.fetchone()
        conn.commit()

        return _json(200, {
            "ok": True,
            "location": {
                "id": row[0], "user_id": row[1], "name": row[2],
                "lat": row[3], "lng": row[4]
            },
            "exists": False
        })

    except Exception:
        if conn:
            try: conn.rollback()
            except Exception: pass
        return _json(500, {"error": "Internal error"})

    finally:
        if cur:
            try: cur.close()
            except Exception: pass
        if conn:
            try: conn.close()
            except Exception: pass
