import json
import psycopg2
import shapely.wkb
from shapely.ops import linemerge
from shapely.geometry import LineString


def lambda_handler(event, context):
    try:
        payload = json.loads(event['body'])
        start_lat, start_lon = payload['start']
        end_lat, end_lon = payload['end']
        allowed = payload.get('allowed') or []

        conn = psycopg2.connect(
            host="osm-data.cplugomkwhlt.us-east-1.rds.amazonaws.com",
            dbname="osm-data",
            user="postgres",
            password="powderpath",
            port="5432"
        )
        
        with conn.cursor() as cur:
            # Build the difficulty filter for the inner edge SQL used by pgr_dijkstra.
            # We inline a TEXT[] literal safely using mogrify on each value.
            if allowed:
                vals = ",".join(cur.mogrify("%s", (v,)).decode("utf-8") for v in allowed)
                allowed_array = f"ARRAY[{vals}]::text[]"
                # Allow all NULL difficulties (for lifts) + any in the allowed list
                difficulty_clause = f" AND (difficulty IS NULL OR difficulty = ANY({allowed_array}))"
            else:
                # No filter (treat as all difficulties allowed). The UI prevents this.
                difficulty_clause = ""

            # Build the inner SQL and pass it as a parameter to pgr_dijkstra
            inner_sql = f"""
                SELECT id, source, target, cost
                FROM routing_edges
                WHERE TRUE{difficulty_clause}
            """

            # Find nearest vertex to start
            cur.execute("""
                SELECT id, ST_Y(ST_Transform(geom, 4326))::float AS lat, ST_X(ST_Transform(geom, 4326))::float AS lon  
                FROM routing_vertices
                ORDER BY geom <-> ST_Transform(ST_SetSRID(ST_MakePoint(%s, %s), 4326), 3857)
                LIMIT 1;
            """, (start_lon, start_lat))
            start_id, snap_start_lat, snap_start_lon = cur.fetchone()

            # Find nearest vertex to end
            cur.execute("""
                SELECT id, ST_Y(ST_Transform(geom, 4326))::float AS lat, ST_X(ST_Transform(geom, 4326))::float AS lon 
                FROM routing_vertices
                ORDER BY geom <-> ST_Transform(ST_SetSRID(ST_MakePoint(%s, %s), 4326), 3857)
                LIMIT 1;
            """, (end_lon, end_lat))
            end_id, snap_end_lat, snap_end_lon = cur.fetchone()

            # Run Dijkstra
            cur.execute("""
                SELECT e.id, e.osm_id, e.name, e.difficulty, ST_AsBinary(ST_Transform(e.geom, 4326))
                FROM pgr_dijkstra(%s, %s, %s, directed := true) AS path
                JOIN routing_edges e ON path.edge = e.id
                ORDER BY path.seq;
            """, (inner_sql, start_id, end_id))

            rows = cur.fetchall()

            # Group consecutive rows with same (osm_id, name)
            grouped_route = []
            current_group = []
            current_key = None

            for row in rows:
                edge_id, osm_id, name, difficulty, geom_wkb = row
                key = (osm_id, name, difficulty)

                geom = shapely.wkb.loads(bytes(geom_wkb))

                if key == current_key:
                    current_group.append(geom)
                else:
                    # Finalize previous group
                    if current_group:
                        merged = linemerge(current_group)
                        grouped_route.append({
                            "osm_id": current_key[0],
                            "name": current_key[1],
                            "difficulty": current_key[2],
                            "geometry": shapely.geometry.mapping(merged),
                        })
                    # Start new group
                    current_key = key
                    current_group = [geom]

            # Add the final group
            if current_group:
                merged = linemerge(current_group)
                grouped_route.append({
                    "osm_id": current_key[0],
                    "name": current_key[1],
                    "difficulty": current_key[2],
                    "geometry": shapely.geometry.mapping(merged),
                })

        return {
            "statusCode": 200,
            "body": json.dumps({
                "route": grouped_route,
                "snapped_start": [snap_start_lat, snap_start_lon],
                "snapped_end"  : [snap_end_lat,  snap_end_lon]
            })
        }
        #     cur.execute("""
        #         SELECT e.id, ST_AsGeoJSON(e.geom), e.cost
        #         FROM pgr_dijkstra(
        #             'SELECT id, source, target, cost FROM routing_edges',
        #             %s, %s,
        #             directed := true
        #         ) AS path
        #         JOIN routing_edges e ON path.edge = e.id
        #         ORDER BY path.seq;
        #     """, (start_id, end_id))

        #     route = [{
        #         "id": row[0],
        #         "geometry": json.loads(row[1]),
        #         "cost": row[2]
        #     } for row in cur.fetchall()]

        # return {
        #     "statusCode": 200,
        #     "body": json.dumps({"route": route})
        # }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
