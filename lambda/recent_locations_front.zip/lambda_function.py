import json
import psycopg2

def _json(status, data):
    return {
        "statusCode": status,
        "headers": {
            "Access-Control-Allow-Origin": "*",   
            "Content-Type": "application/json"
        },
        "body": json.dumps(data, ensure_ascii=False)
    }

def _open_conn():
    return psycopg2.connect(
        host="osm-data.cplugomkwhlt.us-east-1.rds.amazonaws.com",
        dbname="osm-data",
        user="postgres",
        password="powderpath",
        port="5432"
    )

def lambda_handler(event, context):
    # תמיכה גם במיפוי v2 (Function URL) וגם ישן
    method = (event.get("requestContext", {}).get("http", {}).get("method")
              or event.get("httpMethod", "GET")).upper()

    if method != "GET":
        return _json(405, {"error": "Method Not Allowed"})

    params = event.get("queryStringParameters") or {}
    user_id = params.get("user_id")
    if not user_id:
        return _json(400, {"error": "user_id is required"})

    try:
        limit = int(params.get("limit", "5"))
    except ValueError:
        limit = 5
    limit = max(1, min(limit, 20))

    conn = None
    cur = None
    try:
        conn = _open_conn()
        cur = conn.cursor()


        cur.execute(
            """
            SELECT id,
                   user_id,
                   location_name,
                   ST_Y(coordinates) AS lat,
                   ST_X(coordinates) AS lng
            FROM recent_locations
            WHERE user_id = %s
            ORDER BY id DESC
            LIMIT %s;
            """,
            (user_id, limit)
        )
        rows = cur.fetchall()

        items = [
            {
                "id": r[0],
                "user_id": r[1],
                "name": r[2],
                "lat": r[3],
                "lng": r[4]
            }
            for r in rows
        ]
        return _json(200, {"items": items})

    except Exception as e:
        return _json(500, {"error": "Internal error"})
    finally:
        try:
            if cur: cur.close()
        finally:
            if conn: conn.close()
