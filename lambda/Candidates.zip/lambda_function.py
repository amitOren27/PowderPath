import json
import psycopg2

def nearest_vertex_candidates(cur, lat, lon, k=3):
    """
    Return up to K nearest routing vertices to (lat, lon) (WGS84).
    Each row: { id, lat, lon, dist_m }
    """
    cur.execute("""
        SELECT v.id,
               ST_Y(ST_Transform(v.geom, 4326))::float AS lat,
               ST_X(ST_Transform(v.geom, 4326))::float AS lon
        FROM routing_vertices v
        ORDER BY v.geom <-> ST_Transform(ST_SetSRID(ST_MakePoint(%s,%s),4326),3857)
        LIMIT %s;
    """, (lon, lat, k))
    rows = cur.fetchall()
    return [{"id": r[0], "lat": r[1], "lon": r[2]} for r in rows]

def lambda_handler(event, context):
    try:
        payload = json.loads(event.get('body') or '{}')

        stops = payload.get('stops')
        if not isinstance(stops, list) or not stops:
            return {"statusCode": 400, "body": json.dumps({"error": "'stops' must be a non-empty array of [lat,lng]"})}

        k = int(payload.get('k', 3))
        if k <= 0: k = 3

        conn = psycopg2.connect(
            host="osm-data.cplugomkwhlt.us-east-1.rds.amazonaws.com",
            dbname="osm-data",
            user="postgres",
            password="powderpath",
            port="5432"
        )

        all_candidates = []
        with conn.cursor() as cur:
            for s in stops:
                if not (isinstance(s, list) and len(s) == 2):
                    return {"statusCode": 400, "body": json.dumps({"error": "each stop must be [lat, lng]"})}
                lat, lng = float(s[0]), float(s[1])
                cand = nearest_vertex_candidates(cur, lat, lng, k=k)
                all_candidates.append(cand)

        return {
            "statusCode": 200,
            "body": json.dumps({
                "mode": "candidates",
                "k": k,
                "stops_count": len(stops),
                "candidates": all_candidates
            })
        }

    except Exception as e:
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}

