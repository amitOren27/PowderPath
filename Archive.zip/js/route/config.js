
export const ROUTE_URL = 'https://rboamzl423fcfavxa5r2s6p4bm0vvbdr.lambda-url.us-east-1.on.aws/';